package com.example.pr16

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.net.Uri
import android.view.View
import android.widget.Button
import android.widget.Toast

class Settings : AppCompatActivity() {
    private lateinit var List:Button
    private lateinit var alarm:Button
    private lateinit var calendar:Button
    private lateinit var Back:Button
    private lateinit var One:Button
    private lateinit var Two:Button
    private lateinit var Three:Button
    private lateinit var Four:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settingsactivity)
        List = findViewById(R.id.list)
        alarm = findViewById(R.id.alarm)
        calendar = findViewById(R.id.calendar)
        Back = findViewById(R.id.back)
        One = findViewById(R.id.one)
        Two = findViewById(R.id.two)
        Three = findViewById(R.id.three)
        Four = findViewById(R.id.four)
        List.setOnClickListener {
            Toast.makeText(this, R.string.list, Toast.LENGTH_SHORT)
                .show()
        }
        One.setOnClickListener {
            Toast.makeText(this, R.string.list, Toast.LENGTH_SHORT)
                .show()
        }
        Two.setOnClickListener {
            Toast.makeText(this, R.string.list, Toast.LENGTH_SHORT)
                .show()
        }
        Three.setOnClickListener {
            Toast.makeText(this, R.string.list, Toast.LENGTH_SHORT)
                .show()
        }
        Four.setOnClickListener {
            val intent = Intent()
            intent.setAction(Intent.ACTION_VIEW)
            intent.addCategory(Intent.CATEGORY_BROWSABLE)
            intent.setData(Uri.parse("https://support.microsoft.com/ru-ru/windows/%D0%BF%D0%BE%D0%BB%D1%83%D1%87%D0%B5%D0%BD%D0%B8%D0%B5-%D0%BF%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B5%D0%B3%D0%BE-%D0%BE%D0%B1%D0%BD%D0%BE%D0%B2%D0%BB%D0%B5%D0%BD%D0%B8%D1%8F-windows-7d20e88c-0568-483a-37bc-c3885390d212#:~:text=%D0%95%D1%81%D0%BB%D0%B8%20%D0%B2%D1%8B%20%D1%85%D0%BE%D1%82%D0%B8%D1%82%D0%B5%20%D1%83%D1%81%D1%82%D0%B0%D0%BD%D0%BE%D0%B2%D0%B8%D1%82%D1%8C%20%D0%BE%D0%B1%D0%BD%D0%BE%D0%B2%D0%BB%D0%B5%D0%BD%D0%B8%D0%B5,%D0%95%D1%81%D0%BB%D0%B8%20%D0%B4%D0%BE%D1%81%D1%82%D1%83%D0%BF%D0%BD%D1%8B%20%D0%BE%D0%B1%D0%BD%D0%BE%D0%B2%D0%BB%D0%B5%D0%BD%D0%B8%D1%8F%2C%20%D1%83%D1%81%D1%82%D0%B0%D0%BD%D0%BE%D0%B2%D0%B8%D1%82%D0%B5%20%D0%B8%D1%85."))
            startActivity(intent)
        }

        alarm.setOnClickListener {
            val intent = Intent(this, AlarmActivity::class.java)
            startActivity(intent)
        }
        calendar.setOnClickListener {
            val intent = Intent(this, Calendar::class.java)
            startActivity(intent)
        }
        Back.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }



}