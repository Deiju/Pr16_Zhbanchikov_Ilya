package com.example.pr16

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast


class AlarmActivity : AppCompatActivity() {
    private lateinit var List: Button
    private lateinit var calendar: Button
    private lateinit var setting: Button
    private lateinit var Back: Button
    private lateinit var One:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm)
        List=findViewById(R.id.list)
        calendar=findViewById(R.id.calendar)
        setting=findViewById(R.id.setting)
        Back=findViewById(R.id.back)
        One=findViewById(R.id.alarmgive)
        List.setOnClickListener{
            Toast.makeText(this, R.string.list, Toast.LENGTH_SHORT)
                .show()
        }
        One.setOnClickListener{
            Toast.makeText(this, R.string.list, Toast.LENGTH_SHORT)
                .show()
        }
        calendar.setOnClickListener{
            val intent = Intent(this, Calendar::class.java)
            startActivity(intent)
        }
        setting.setOnClickListener{
            val intent= Intent(this, Settings::class.java)
            startActivity(intent)
        }
        Back.setOnClickListener{
            val intent= Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }
}