package com.example.pr16

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {
    private lateinit var registry:Button
    private lateinit var exi:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        registry=findViewById(R.id.regis)
        exi=findViewById(R.id.exit)
        exi.setOnClickListener{
            finishAffinity()
        }
        registry.setOnClickListener{
            val intent = Intent(this, Settings::class.java)
            startActivity(intent)
        }
    }

}