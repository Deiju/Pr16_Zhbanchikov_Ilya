package com.example.pr16

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class Calendar : AppCompatActivity() {
    private lateinit var List: Button
    private lateinit var alarm: Button
    private lateinit var setting: Button
    private lateinit var Back: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activitycalendar)
        List=findViewById(R.id.list)
        alarm=findViewById(R.id.alarm)
        setting=findViewById(R.id.setting)
        Back=findViewById(R.id.back)
        List.setOnClickListener{
            Toast.makeText(this, R.string.list, Toast.LENGTH_SHORT)
                .show()
        }
        alarm.setOnClickListener{
            val intent = Intent(this, AlarmActivity::class.java)
            startActivity(intent)
        }
        setting.setOnClickListener{
            val intent= Intent(this, Settings::class.java)
            startActivity(intent)
        }
        Back.setOnClickListener{
            val intent= Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }
}